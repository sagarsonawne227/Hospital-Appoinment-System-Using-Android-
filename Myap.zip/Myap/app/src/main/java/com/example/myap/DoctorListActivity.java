package com.example.myap;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.myap.database.DatabaseHelper;
import java.util.ArrayList;
import java.util.List;

public class DoctorListActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private ListView doctorListView;
    private List<Doctor> doctorList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);

        databaseHelper = new DatabaseHelper(this);
        doctorListView = findViewById(R.id.doctorListView);
        doctorList = new ArrayList<>();

        loadDoctors();
        setupDoctorList();
    }

    private void loadDoctors() {
        // Add sample doctors if the list is empty
        if (getDoctorCount() == 0) {
            addSampleDoctors();
        }

        // Load doctors from database
        Cursor cursor = databaseHelper.getAllDoctors();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                Doctor doctor = new Doctor(
                    cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME)),
                    cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_SPECIALIZATION)),
                    cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_EXPERIENCE)),
                    cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PHONE))
                );
                doctorList.add(doctor);
            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    private int getDoctorCount() {
        Cursor cursor = databaseHelper.getAllDoctors();
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    private void addSampleDoctors() {
        databaseHelper.addDoctor("Dr. John Smith", "Cardiologist", 15, "1234567890");
        databaseHelper.addDoctor("Dr. Sarah Johnson", "Pediatrician", 10, "2345678901");
        databaseHelper.addDoctor("Dr. Michael Brown", "Neurologist", 12, "3456789012");
        databaseHelper.addDoctor("Dr. Emily Davis", "Dermatologist", 8, "4567890123");
    }

    private void setupDoctorList() {
        ArrayAdapter<Doctor> adapter = new ArrayAdapter<Doctor>(this, R.layout.doctor_list_item, R.id.doctorName, doctorList) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.doctor_list_item, parent, false);
                }

                Doctor doctor = getItem(position);
                if (doctor != null) {
                    TextView nameText = convertView.findViewById(R.id.doctorName);
                    TextView specialityText = convertView.findViewById(R.id.doctorSpeciality);
                    TextView experienceText = convertView.findViewById(R.id.doctorExperience);
                    Button bookButton = convertView.findViewById(R.id.bookAppointmentButton);

                    nameText.setText(doctor.getName());
                    specialityText.setText(doctor.getSpecialization());
                    experienceText.setText(doctor.getExperience() + " years experience");

                    bookButton.setOnClickListener(v -> {
                        Intent intent = new Intent(DoctorListActivity.this, AppointmentActivity.class);
                        intent.putExtra("doctor_id", doctor.getId());
                        intent.putExtra("doctor_name", doctor.getName());
                        startActivity(intent);
                    });
                }
                return convertView;
            }
        };
        doctorListView.setAdapter(adapter);
    }

    private static class Doctor {
        private int id;
        private String name;
        private String specialization;
        private int experience;
        private String phone;

        public Doctor(int id, String name, String specialization, int experience, String phone) {
            this.id = id;
            this.name = name;
            this.specialization = specialization;
            this.experience = experience;
            this.phone = phone;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getSpecialization() { return specialization; }
        public int getExperience() { return experience; }
        public String getPhone() { return phone; }
    }
}

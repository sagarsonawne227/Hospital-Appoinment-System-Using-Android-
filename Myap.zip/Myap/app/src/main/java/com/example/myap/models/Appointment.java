package com.example.myap.models;

public class Appointment {
    private String id;
    private String userId;
    private String doctorId;
    private String date;
    private String time;
    private String status; // "pending", "confirmed", "cancelled"

    public Appointment() {
        // Required empty constructor for Firebase
    }

    public Appointment(String id, String userId, String doctorId, String date, String time, String status) {
        this.id = id;
        this.userId = userId;
        this.doctorId = doctorId;
        this.date = date;
        this.time = time;
        this.status = status;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    
    public String getDoctorId() { return doctorId; }
    public void setDoctorId(String doctorId) { this.doctorId = doctorId; }
    
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}

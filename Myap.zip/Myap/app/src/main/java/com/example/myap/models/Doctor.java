package com.example.myap.models;

public class Doctor {
    private String id;
    private String name;
    private String specialization;
    private String experience;
    private String availability;

    public Doctor() {
        // Required empty constructor for Firebase
    }

    public Doctor(String id, String name, String specialization, String experience, String availability) {
        this.id = id;
        this.name = name;
        this.specialization = specialization;
        this.experience = experience;
        this.availability = availability;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    
    public String getExperience() { return experience; }
    public void setExperience(String experience) { this.experience = experience; }
    
    public String getAvailability() { return availability; }
    public void setAvailability(String availability) { this.availability = availability; }
}

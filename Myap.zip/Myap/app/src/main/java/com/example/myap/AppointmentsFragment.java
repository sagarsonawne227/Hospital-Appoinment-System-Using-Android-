package com.example.myap;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import com.example.myap.database.DatabaseHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppointmentsFragment extends Fragment {
    private DatabaseHelper databaseHelper;
    private ListView appointmentsList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_appointments, container, false);

        databaseHelper = new DatabaseHelper(getContext());
        appointmentsList = view.findViewById(R.id.appointmentsList);
        Button newAppointmentButton = view.findViewById(R.id.newAppointmentButton);

        newAppointmentButton.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), DoctorListActivity.class);
            startActivity(intent);
        });

        loadAppointments();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAppointments();
    }

    private void loadAppointments() {
        // For now, using a dummy user ID (1). In a real app, get this from logged-in user session
        int userId = 1;
        Cursor cursor = databaseHelper.getAppointmentsForUser(userId);
        List<Map<String, String>> data = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Map<String, String> item = new HashMap<>();
                item.put("doctor", cursor.getString(cursor.getColumnIndex("doctor_name")));
                item.put("specialization", cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_SPECIALIZATION)));
                item.put("date", cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE)));
                item.put("time", cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TIME)));
                item.put("status", cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_STATUS)));
                data.add(item);
            } while (cursor.moveToNext());
            cursor.close();
        }

        SimpleAdapter adapter = new SimpleAdapter(
            getContext(),
            data,
            R.layout.appointment_list_item,
            new String[]{"doctor", "specialization", "date", "time", "status"},
            new int[]{R.id.doctorName, R.id.specialization, R.id.appointmentDate, R.id.appointmentTime, R.id.appointmentStatus}
        );

        appointmentsList.setAdapter(adapter);
    }
}

package com.example.myap;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import androidx.fragment.app.Fragment;
import com.example.myap.database.DatabaseHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryFragment extends Fragment {
    private DatabaseHelper databaseHelper;
    private ListView historyList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);

        databaseHelper = new DatabaseHelper(getContext());
        historyList = view.findViewById(R.id.historyList);

        loadHistory();
        return view;
    }

    private void loadHistory() {
        // For now, using a dummy user ID (1). In a real app, get this from logged-in user session
        int userId = 1;
        Cursor cursor = databaseHelper.getAppointmentsForUser(userId);
        List<Map<String, String>> data = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String status = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_STATUS));
                // Only show completed or cancelled appointments in history
                if ("Completed".equals(status) || "Cancelled".equals(status)) {
                    Map<String, String> item = new HashMap<>();
                    item.put("doctor", cursor.getString(cursor.getColumnIndex("doctor_name")));
                    item.put("specialization", cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_SPECIALIZATION)));
                    item.put("date", cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE)));
                    item.put("time", cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TIME)));
                    item.put("status", status);
                    data.add(item);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        SimpleAdapter adapter = new SimpleAdapter(
            getContext(),
            data,
            R.layout.appointment_list_item,
            new String[]{"doctor", "specialization", "date", "time", "status"},
            new int[]{R.id.doctorName, R.id.specialization, R.id.appointmentDate, R.id.appointmentTime, R.id.appointmentStatus}
        );

        historyList.setAdapter(adapter);
    }
}

package com.example.myap;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.myap.database.DatabaseHelper;
import java.util.Calendar;
import java.util.Locale;

public class AppointmentActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private int doctorId;
    private String selectedDate = "";
    private String selectedTime = "";
    private TextView doctorNameText, dateText, timeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        databaseHelper = new DatabaseHelper(this);
        doctorId = getIntent().getIntExtra("doctor_id", -1);
        String doctorName = getIntent().getStringExtra("doctor_name");

        doctorNameText = findViewById(R.id.doctorNameText);
        dateText = findViewById(R.id.dateText);
        timeText = findViewById(R.id.timeText);
        Button selectDateButton = findViewById(R.id.selectDateButton);
        Button selectTimeButton = findViewById(R.id.selectTimeButton);
        Button bookButton = findViewById(R.id.bookButton);

        doctorNameText.setText(doctorName);

        selectDateButton.setOnClickListener(v -> showDatePicker());
        selectTimeButton.setOnClickListener(v -> showTimePicker());
        bookButton.setOnClickListener(v -> bookAppointment());
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
            this,
            (view, year, month, dayOfMonth) -> {
                selectedDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                dateText.setText(selectedDate);
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        );

        // Set minimum date to today
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();
        TimePickerDialog timePickerDialog = new TimePickerDialog(
            this,
            (view, hourOfDay, minute) -> {
                selectedTime = String.format(Locale.US, "%02d:%02d", hourOfDay, minute);
                timeText.setText(selectedTime);
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        );
        timePickerDialog.show();
    }

    private void bookAppointment() {
        if (doctorId == -1) {
            Toast.makeText(this, "Invalid doctor selected", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedDate.isEmpty() || selectedTime.isEmpty()) {
            Toast.makeText(this, "Please select date and time", Toast.LENGTH_SHORT).show();
            return;
        }

        // For now, using a dummy user ID (1). In a real app, get this from logged-in user session
        int userId = 1;
        long result = databaseHelper.bookAppointment(userId, doctorId, selectedDate, selectedTime);

        if (result != -1) {
            Toast.makeText(this, "Appointment booked successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to book appointment", Toast.LENGTH_SHORT).show();
        }
    }
}

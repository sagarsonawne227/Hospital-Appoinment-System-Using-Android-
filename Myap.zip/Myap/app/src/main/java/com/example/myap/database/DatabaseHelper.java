package com.example.myap.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "DoctorAppointment.db";
    private static final int DATABASE_VERSION = 1;

    // Table Names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_DOCTORS = "doctors";
    public static final String TABLE_APPOINTMENTS = "appointments";

    // Common column names
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_PHONE = "phone";

    // Doctors Table additional columns
    public static final String COLUMN_SPECIALIZATION = "specialization";
    public static final String COLUMN_EXPERIENCE = "experience";

    // Appointments Table columns
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_DOCTOR_ID = "doctor_id";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_STATUS = "status";

    // Create table statements
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NAME + " TEXT,"
            + COLUMN_EMAIL + " TEXT UNIQUE,"
            + COLUMN_PASSWORD + " TEXT,"
            + COLUMN_PHONE + " TEXT"
            + ")";

    private static final String CREATE_TABLE_DOCTORS = "CREATE TABLE " + TABLE_DOCTORS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NAME + " TEXT,"
            + COLUMN_SPECIALIZATION + " TEXT,"
            + COLUMN_EXPERIENCE + " INTEGER,"
            + COLUMN_PHONE + " TEXT"
            + ")";

    private static final String CREATE_TABLE_APPOINTMENTS = "CREATE TABLE " + TABLE_APPOINTMENTS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_ID + " INTEGER,"
            + COLUMN_DOCTOR_ID + " INTEGER,"
            + COLUMN_DATE + " TEXT,"
            + COLUMN_TIME + " TEXT,"
            + COLUMN_STATUS + " TEXT,"
            + "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + "),"
            + "FOREIGN KEY(" + COLUMN_DOCTOR_ID + ") REFERENCES " + TABLE_DOCTORS + "(" + COLUMN_ID + ")"
            + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_USERS);
            db.execSQL(CREATE_TABLE_DOCTORS);
            db.execSQL(CREATE_TABLE_APPOINTMENTS);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_APPOINTMENTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOCTORS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            onCreate(db);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // User operations
    public long registerUser(String name, String email, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put(COLUMN_NAME, name);
            values.put(COLUMN_EMAIL, email);
            values.put(COLUMN_PASSWORD, password);
            values.put(COLUMN_PHONE, phone);
            return db.insert(TABLE_USERS, null, values);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            String[] columns = {COLUMN_ID};
            String selection = COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?";
            String[] selectionArgs = {email, password};
            Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
            int count = cursor.getCount();
            cursor.close();
            return count > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Cursor getUserByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID, COLUMN_NAME, COLUMN_EMAIL, COLUMN_PHONE};
        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};
        return db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
    }

    // Doctor operations
    public long addDoctor(String name, String specialization, int experience, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put(COLUMN_NAME, name);
            values.put(COLUMN_SPECIALIZATION, specialization);
            values.put(COLUMN_EXPERIENCE, experience);
            values.put(COLUMN_PHONE, phone);
            return db.insert(TABLE_DOCTORS, null, values);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public Cursor getAllDoctors() {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            return db.query(TABLE_DOCTORS, null, null, null, null, null, COLUMN_NAME + " ASC");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Cursor getDoctorById(int doctorId) {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            String selection = COLUMN_ID + " = ?";
            String[] selectionArgs = {String.valueOf(doctorId)};
            return db.query(TABLE_DOCTORS, null, selection, selectionArgs, null, null, null);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Appointment operations
    public long bookAppointment(int userId, int doctorId, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put(COLUMN_USER_ID, userId);
            values.put(COLUMN_DOCTOR_ID, doctorId);
            values.put(COLUMN_DATE, date);
            values.put(COLUMN_TIME, time);
            values.put(COLUMN_STATUS, "Pending");
            return db.insert(TABLE_APPOINTMENTS, null, values);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public Cursor getAppointmentsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            String query = "SELECT a.*, d." + COLUMN_NAME + " as doctor_name, d." + COLUMN_SPECIALIZATION +
                    " FROM " + TABLE_APPOINTMENTS + " a" +
                    " JOIN " + TABLE_DOCTORS + " d ON a." + COLUMN_DOCTOR_ID + " = d." + COLUMN_ID +
                    " WHERE a." + COLUMN_USER_ID + " = ?" +
                    " ORDER BY a." + COLUMN_DATE + " DESC, a." + COLUMN_TIME + " ASC";
            return db.rawQuery(query, new String[]{String.valueOf(userId)});
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
